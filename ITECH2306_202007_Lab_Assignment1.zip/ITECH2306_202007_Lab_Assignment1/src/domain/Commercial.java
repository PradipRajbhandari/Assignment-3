package domain;

/**
 * @author Takeogh
 * @version 1.0
 * @created 02-Apr-2020 8:30:00am
 */
public class Commercial extends Property  {

	public Commercial() {
		System.out.println("Not implemented yet");
	}

	@Override
	public void setUpExtraServices() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public double calculateExtraServices() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
}
