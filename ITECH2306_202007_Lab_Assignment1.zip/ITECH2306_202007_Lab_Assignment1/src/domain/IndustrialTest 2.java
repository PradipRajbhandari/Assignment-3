package domain;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class IndustrialTest {

	@Test

	public void testPositive1() {

		ServiceType industrialWasteManagement = new UnitAndRateService("Industrial Waste Management",4,500);

		double value=industrialWasteManagement.calculateChargeForServiceType();

		assertEquals(2000,value,0);

			

		}



		@Test

	public void testNegative1() {

		ServiceType industrialWasteManagement = new UnitAndRateService("Industrial Waste Management",4,500);

		double value=industrialWasteManagement.calculateChargeForServiceType();

		assertEquals(2500,value,0);

			

		}

		



		

		

		

		

		@Test

	public void testIndustrialDataPositive() {

		Industrial industrial = new Industrial();

		double value=industrial.getCapitalImprovedValue();

		assertEquals(0.0059,value,0);

			

		}

		

		

		

		@Test

	public void testIndustrialDataNegative() {

		Industrial industrial = new Industrial();

		double value=industrial.getCapitalImprovedValue();

		assertEquals(0.0061,value,0);

			
		}}

