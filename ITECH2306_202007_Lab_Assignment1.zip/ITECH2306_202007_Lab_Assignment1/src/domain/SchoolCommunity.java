package domain;

/**
 * @author Pradip Rajbhandari
 * @version 1.1
 * @created  2 May-2020 8:30:00am
 */
/**
 This is my java Doc file
 *
 */

public class SchoolCommunity extends Property{
	

	private String classification;
	/**
	 * All  the value have been set in the variable
	 * 
	 */
	private String category;
	
	private static final double CIV_RATE= 0.0025;//0.25%
	private static final int Industrial_Waste_Disposal_UNITS= 2;
	private static final double Industrial_Waste_Disposal_FEES=500.00;
	private static final double FIRE_SERVICES_BASE= 200;
	private static final double FIRE_SERVICES_PERCENT= 0.00006;//0.006%
	private static final double TRAFFIC_MANAGEMENT_BASE= 200;

	private double categoryAmount=0;
	private ServiceType industrialWasteManagement;
	private ServiceType fireServicesLevy;
	private ServiceType trafficManagementLevy;
	
	
	
	
public double getCategoryAmount()

	

	{ 

		return this.categoryAmount;

	}
	
	 
	
	/**
	 * @param Category int value
	 * 
	 * SO I have keep the category as the option to have respective category amount
	 */


	public SchoolCommunity(int Category) {
		super();
		// We are explicit about our defaults for Strings
		this.setClassification("public");
		this.setCategory("Lower Secondary");
				
		setCapitalImprovedRate(CIV_RATE);
		
		
        switch(Category) {
		
		case 1:
		
			this.categoryAmount=60;
			
			break;
		case 2:
			this.categoryAmount=80;
			break;
		case 3:
			this.categoryAmount=100;
			break;
        default:
        	this.categoryAmount=0;
			break;
		}

	}
	
	

	/**
	 * @return classificaiion
	 */
	public String getClassification() {
		return classification;
	}


	/**
	 * @param classification is set
	 */
	public void setClassification(String classification) {
		this.classification = classification;
	}
	/**
	 * @return category
	 */
	public String getCategory() {
		return category;
	}


	/**
	 * @param category is set
	 */
	public void setCategory(String category) {
		this.category = category;
	}
	

	
	/**
	 * This is the calculate Extra Services method which will return the total calulation services.
	 */
	
	@Override
	public double calculateExtraServices() {
		// TODO Auto-generated method stub
		return industrialWasteManagement.calculateChargeForServiceType()+
				fireServicesLevy.calculateChargeForServiceType()+trafficManagementLevy.calculateChargeForServiceType();
	}
	

	/**
	 * The extra service method is set which will helps to perform the calculation
	 */
	@Override
	public void setUpExtraServices() {
		// TODO Auto-generated method stub
		industrialWasteManagement= new UnitAndRateService("Industrial Waste Management",
		Industrial_Waste_Disposal_UNITS,
		Industrial_Waste_Disposal_FEES);
		trafficManagementLevy= new BaseAndExtraService("traffic Management",TRAFFIC_MANAGEMENT_BASE,this.categoryAmount);
		fireServicesLevy = new BaseAndPercentageOfValueService("Fire Levy",
				FIRE_SERVICES_BASE,
				FIRE_SERVICES_PERCENT,
				getCapitalImprovedValue());
	
	}
	/**
	 * this will return the final value to the main schoolcommunity.
	 */
	@Override
	public String toString() 
	{
		return  super.toString() + "SchoolCommunity [\n" + 
				industrialWasteManagement.toString() + "\n" +
									fireServicesLevy.toString() + " \n"+
											trafficManagementLevy.toString() +"]\n";
	}



	
}

