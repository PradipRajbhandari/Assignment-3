package domain;

/**
 * @author vivek kumar Gupta
 * @version 1.0
 * @created 10-May-2020 8:30:00am
 */
public  class Hospital extends Property{
	
	private String privateStatus;
	private String facilities;
	private String numberOfFloors;
	
	private static final double CIV_RATE= 0.0035;//0.35%
	private static final int Industrial_Waste_Disposal_UNITS= 4;
	private static final double Industrial_Waste_Disposal_FEES=500.00;
	private static final double FIRE_SERVICES_BASE= 200;
	private static final double FIRE_SERVICES_PERCENT= 0.00006;//0.006%
	 
	private ServiceType industrialWasteManagement;
	private ServiceType fireServicesLevy;
	
	
	public Hospital() {
		super();
		// We are explicit about our defaults for Strings
		this.setPrivateStatus("Not avaliable");
		this.setFacilities("Not avaliable");
		this.setNumberOfFloors("Not avaliable");
		setCapitalImprovedRate(CIV_RATE); 
	}
	
		
		public String getPrivateStatus() {
			return privateStatus;
		}

		public void setPrivateStatus(String privateStatus) {
			this.privateStatus = privateStatus;
		}

		public String getFacilities() {
			return facilities;
		}

		public void setFacilities(String facilities){
			this.facilities = facilities;
		}
		
		public String getNumberOfFloors() {
			return numberOfFloors;
		}

		public void setNumberOfFloors(String numberOfFloors) {
			this.numberOfFloors = numberOfFloors;
	    }



		@Override
		public double calculateExtraServices() {
			// TODO Auto-generated method stub
			return industrialWasteManagement.calculateChargeForServiceType()+
					fireServicesLevy.calculateChargeForServiceType();
		}

		@Override
		public void setUpExtraServices() {
			// TODO Auto-generated method stub
			industrialWasteManagement= new UnitAndRateService("Industrial Waste Management",
			Industrial_Waste_Disposal_UNITS,
			Industrial_Waste_Disposal_FEES);
			fireServicesLevy = new BaseAndPercentageOfValueService("Fire Levy",
					FIRE_SERVICES_BASE,
					FIRE_SERVICES_PERCENT,
					getCapitalImprovedValue());
		}
		@Override
		public String toString() {
			return  super.toString() + "Hospital [\n" + 
					industrialWasteManagement.toString() + "\n" +
										fireServicesLevy.toString() + " ]\n ";
		}

	}
