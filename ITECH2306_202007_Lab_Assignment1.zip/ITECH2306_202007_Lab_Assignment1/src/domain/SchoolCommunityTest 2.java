package domain;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class SchoolCommunityTest {

	@Test

	public void testPositive() {

		ServiceType trafficManagement = new BaseAndExtraService("Traffic Management",200,60);

		double value=trafficManagement.calculateChargeForServiceType();

		assertEquals(260,value,0);

			

		}

		

		



		@Test

	public void testNegative() {

		ServiceType trafficManagement = new BaseAndExtraService("Traffic Management",200,60);

		double value=trafficManagement.calculateChargeForServiceType();

		assertEquals(250,value,0);

			

		}

		

		

		



		@Test

	public void testSwitchStatementPositive() {

		SchoolCommunity sc= new SchoolCommunity(1);

		double value=sc.getCategoryAmount();

		assertEquals(60,value,0);

			

		}

		

		@Test

	public void testSwitchStatementNegative() {

		SchoolCommunity sc= new SchoolCommunity(1);

		double value=sc.getCategoryAmount();

		assertEquals(80,value,0);

			

		}

		





		

		

		

		

	}
