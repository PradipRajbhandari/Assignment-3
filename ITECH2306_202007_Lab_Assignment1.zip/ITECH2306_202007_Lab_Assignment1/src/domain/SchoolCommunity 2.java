package domain;

/**
 * @author Pradip Rajbhandari
 * @version 1.1
 * @created  2 May-2020 8:30:00am
 */
public class SchoolCommunity extends Property{
	

	private String classification;
	private String category;
	
	private static final double CIV_RATE= 0.0025;//0.25%
	private static final int Industrial_Waste_Disposal_UNITS= 2;
	private static final double Industrial_Waste_Disposal_FEES=500.00;
	private static final double FIRE_SERVICES_BASE= 200;
	private static final double FIRE_SERVICES_PERCENT= 0.00006;//0.006%
	private static final double TRAFFIC_MANAGEMENT_BASE= 200;

	private double categoryAmount=0;
	private ServiceType industrialWasteManagement;
	private ServiceType fireServicesLevy;
	private ServiceType trafficManagementLevy;
	
public double getCategoryAmount()

	

	{ 

		return this.categoryAmount;

	}
	
	 
	
	public SchoolCommunity(int Category) {
		super();
		// We are explicit about our defaults for Strings
		this.setClassification("public");
		this.setCategory("Lower Secondary");
				
		setCapitalImprovedRate(CIV_RATE);
		
		
        switch(Category) {
		
		case 1:
		
			this.categoryAmount=60;
			
			break;
		case 2:
			this.categoryAmount=80;
			break;
		case 3:
			this.categoryAmount=100;
			break;
        default:
        	this.categoryAmount=0;
			break;
		}

	}
	
	

	public String getClassification() {
		return classification;
	}


	public void setClassification(String classification) {
		this.classification = classification;
	}
	public String getCategory() {
		return category;
	}


	public void setCategory(String category) {
		this.category = category;
	}
	

	
	@Override
	public double calculateExtraServices() {
		// TODO Auto-generated method stub
		return industrialWasteManagement.calculateChargeForServiceType()+
				fireServicesLevy.calculateChargeForServiceType()+trafficManagementLevy.calculateChargeForServiceType();
	}

	@Override
	public void setUpExtraServices() {
		// TODO Auto-generated method stub
		industrialWasteManagement= new UnitAndRateService("Industrial Waste Management",
		Industrial_Waste_Disposal_UNITS,
		Industrial_Waste_Disposal_FEES);
		trafficManagementLevy= new BaseAndExtraService("traffic Management",TRAFFIC_MANAGEMENT_BASE,this.categoryAmount);
		fireServicesLevy = new BaseAndPercentageOfValueService("Fire Levy",
				FIRE_SERVICES_BASE,
				FIRE_SERVICES_PERCENT,
				getCapitalImprovedValue());
	
	}
	@Override
	public String toString() 
	{
		return  super.toString() + "SchoolCommunity [\n" + 
				industrialWasteManagement.toString() + "\n" +
									fireServicesLevy.toString() + " \n"+
											trafficManagementLevy.toString() +"]\n";
	}



	
}

