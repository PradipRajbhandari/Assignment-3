package utility;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import domain.RatePayer;
//pradip
class LoadPropertiesTest {

		
	public void testPayer() {
		LoadProperties lp=new LoadProperties("Commercial",false);
		String Description=lp.getDescription();
		assertEquals("Commercial",Description,0);
	}

}
