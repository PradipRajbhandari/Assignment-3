package utility;

import static org.junit.Assert.assertEquals;
import org.junit.jupiter.api.Test;

import domain.RatePayer;

class LoadRatePayerTest {

	@Test
	public void testPayer() {
		RatePayer r=new RatePayer("vivek","Gupta","sydney","Nepal","80",false);
		String name=r.getName();
		assertEquals("vivek",name,0);
	}

}
