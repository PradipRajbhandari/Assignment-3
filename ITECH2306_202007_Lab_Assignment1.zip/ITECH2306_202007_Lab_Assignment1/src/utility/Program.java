package utility;

import java.io.IOException;

import operation.MainMenu;
public class Program {
public static void main(String[] args)  throws IOException {
		
String dir="C:/Users/User/git/repository/itech2306-202007-lab-assignment1-vivek-gupta-team/ITECH2306_202007_Lab_Assignment1/src/utility";
String filename="ITECH2306_2020_Load_RatePayers.csv";  
	
LoadRatePayer lr= new LoadRatePayer(filename,dir);

lr.readRatePayersFromCSV();


lr.serialize_objects();

lr.deserialize_objects();		  
		  
		

String fname="ITECH2306_2020_LoadProperties.csv"; 
LoadProperties lp= new LoadProperties(fname,dir);
lp.readPropertiesFromCSV();
	  }
}
