package utility;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

import domain.*;

public class LoadProperties {
	
	private static final int communityCategory = 0;
	private String filename;
	private String dir;
	ArrayList<Property> PropertyList;
	
	public LoadProperties(String fn,String dir) {
		this.setFilename(fn);
		this.setDir(dir);
	}
	
	public void readPropertiesFromCSV() {
		
		Path pathToFile=Paths.get(this.dir+File.separator+this.filename);
		BufferedReader br;
		try {
			br = Files.newBufferedReader(pathToFile);
			String line=br.readLine();
			while(line!=null) {
				String[] attributes=line.split(",");
				String propertyType=attributes[0];
				Property prop;
				
				switch(propertyType){
				case "Commercial":
				    prop= new Commercial();
					break;
				case "Industrial":
					prop=new Industrial();
					break;	
               case "Residental":
					prop=new Residential();
					break;
					
				case"Hospital":
					prop=new Hospital();
					break;
					
				case "SchoolCommunity":
				prop=new SchoolCommunity(communityCategory); 
					break;
				
			}
			}
		
	}
		catch(IOException e) {
		//TODO auto-generated catch block	
		}
		}
	
	public String getFilename() {
		return filename;
		
	}
	public void setFilename( String filename) {
		this.filename=filename;
	}
   public String getDir() {
	  return dir;
   }
   
   public void setDir(String dir) {
	   this.dir= dir;
   }
}
