package operation;

import java.util.Scanner;

/**
 * @author Takeogh
 * @version 1.0
 * @created 02-Apr-2020 8:30:00am
 */
public class AddProperty extends FunctionalDialog {

	public AddProperty(Scanner console) {
		super(1,console);
	}

	@Override
	public void obtainInput(int i) {
		System.out.println("Not implemented yet");
		setStillRunning(false);	
	}

	@Override
	public void respondToInput() {
		// TODO Auto-generated method stub
		
	}

}
